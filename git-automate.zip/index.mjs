// GitHub API Library
import { Octokit } from '@octokit/rest';
import fetch from 'node-fetch';

const gitTokens = ['тут вставляем ваш API от аккаунта №1', 'тут вставляем ваш API от аккаунта №2'];
const gitNames = ['тут вставляем ваш nickname от аккаунта №1', 'тут вставляем ваш nickname от аккаунта №2'];

function generateUniqueName() {
    return `fact_${Math.floor(Math.random() * 150000000)}.txt`;
}

async function pushRandomCatName(repoOwner, token) {
    const octokit = new Octokit({ auth: token });

    try {
        const branchFilesData = await octokit.repos.getContent({
            owner: repoOwner,
            repo: 'randomCatFacts',
            branch: 'main',
        });

        console.log(branchFilesData, 'branchFilesData');

        const catsResponse = await fetch("https://catfact.ninja/fact");
        const { fact } = await catsResponse.json();

        let randomName = generateUniqueName();

        const isAlreadyFileNameExist = !!branchFilesData.data.find((user) => {
            return user.path === randomName;
        });

        if (isAlreadyFileNameExist) {
            await pushRandomCatName(repoOwner, token);
        }

        await octokit.repos.createOrUpdateFileContents({
            owner: repoOwner,
            repo: 'randomCatFacts',
            path: randomName,
            message: 'Another great day with great cat fact',
            content: Buffer.from(fact).toString('base64'),
            branch: 'main',
        });
        console.log('Pushed fact to randomCatFacts');
    } catch (error) {
        console.error('Error pushing fact to randomCatFacts', error);
        throw error; // Rethrow the error to ensure AWS Lambda recognizes the failure
    }
}

export const handler = async (event, context) => {
    try {
        for (let index = 0; index < gitTokens.length; index++) {
            await pushRandomCatName(gitNames[index], gitTokens[index]);
        }
        return { statusCode: 200, body: 'Success' };
    } catch (error) {
        console.error('Lambda execution failed:', error);
        return { statusCode: 500, body: 'Internal Server Error' };
    }
};
